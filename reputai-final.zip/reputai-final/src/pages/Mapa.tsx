import React, { useEffect, useRef, useState } from 'react';
import { MapPin, RotateCcw, Crosshair, Filter, Search, X, Building2 } from 'lucide-react';
import { useCompanies } from '@/hooks/useCompanies';
import { useNavigate } from 'react-router-dom';
import { useToastContext } from '@/contexts/ToastContext';
import { useAuth } from '@/contexts/AuthContext';

const getMarkerColor = (rating: number) => {
  if (rating >= 4.5) return '#10b981';
  if (rating >= 3.5) return '#3b82f6';
  if (rating >= 2.5) return '#f59e0b';
  return '#dc2626';
};

const MapaPage: React.FC = () => {
  const { companies, updateCompany } = useCompanies();
  const { isAdmin } = useAuth();
  const { showToast } = useToastContext();
  const navigate = useNavigate();
  const [sectorFilter, setSectorFilter] = useState('');
  const [userPos, setUserPos] = useState<[number, number] | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [mapError, setMapError] = useState(false);
  const [clusterPopup, setClusterPopup] = useState<{ companies: typeof companies; position: string } | null>(null);
  const [clusterSearch, setClusterSearch] = useState('');
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  const filtered = sectorFilter ? companies.filter(c => c.sector === sectorFilter) : companies;

  // Group companies by same lat/lng (commercial buildings)
  const groupByLocation = (comps: typeof companies) => {
    const groups: Record<string, typeof companies> = {};
    comps.forEach(c => {
      if (!c.lat || !c.lng) return;
      const key = `${c.lat.toFixed(4)},${c.lng.toFixed(4)}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(c);
    });
    return groups;
  };

  useEffect(() => {
    const initMap = async () => {
      try {
        const L = await import('leaflet');
        delete (L.Icon.Default.prototype as any)._getIconUrl;
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
          iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
          shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
        });
        if (!mapContainerRef.current || mapInstanceRef.current) return;
        const map = L.map(mapContainerRef.current).setView([-15.793889, -47.882778], 4);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        }).addTo(map);
        mapInstanceRef.current = map;
        setMapReady(true);
        setTimeout(() => map.invalidateSize(), 100);
      } catch {
        setMapError(true);
      }
    };
    initMap();
    return () => { if (mapInstanceRef.current) { mapInstanceRef.current.remove(); mapInstanceRef.current = null; } };
  }, []);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapReady) return;
    import('leaflet').then((L) => {
      markersRef.current.forEach(m => m.remove());
      markersRef.current = [];

      // Admins see every company as an individual draggable marker so they can reposition each one.
      const groups = isAdmin
        ? Object.fromEntries(
            filtered
              .filter(c => c.lat && c.lng)
              .map(c => [`${c.id}`, [c]])
          )
        : groupByLocation(filtered);

      Object.entries(groups).forEach(([key, groupCompanies]) => {
        const isCluster = groupCompanies.length > 1;
        const lat = isCluster ? Number(key.split(',')[0]) : (groupCompanies[0].lat as number);
        const lng = isCluster ? Number(key.split(',')[1]) : (groupCompanies[0].lng as number);
        const avgRating = groupCompanies.reduce((s, c) => s + c.average_rating, 0) / groupCompanies.length;
        const color = getMarkerColor(avgRating);

        const icon = L.divIcon({
          className: 'custom-marker',
          html: `<div style="background:${color};width:${isCluster ? 36 : 28}px;height:${isCluster ? 36 : 28}px;border-radius:50%;border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:${isCluster ? 14 : 0}px;">
            ${isCluster ? groupCompanies.length : `<svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M19 21V5a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5h4v5m-4 0h4"/></svg>`}
          </div>`,
          iconSize: [isCluster ? 36 : 28, isCluster ? 36 : 28],
          iconAnchor: [isCluster ? 18 : 14, isCluster ? 18 : 14],
        });

        const draggable = isAdmin && !isCluster;
        const marker = L.marker([lat, lng], { icon, draggable }).addTo(map);

        if (draggable) {
          const c = groupCompanies[0];
          marker.on('dragend', async () => {
            const pos = marker.getLatLng();
            const ok = await updateCompany(c.id, { lat: pos.lat, lng: pos.lng });
            showToast(ok ? `Localização de ${c.name} atualizada` : 'Erro ao atualizar', ok ? 'success' : 'error');
          });
          marker.bindTooltip('Arraste para reposicionar', { direction: 'top', offset: [0, -14] });
        }

        if (isCluster) {
          marker.on('click', () => {
            setClusterPopup({ companies: groupCompanies.sort((a, b) => a.name.localeCompare(b.name)), position: key });
            setClusterSearch('');
          });
        } else {
          const c = groupCompanies[0];
          const adminHint = draggable ? '<p style="font-size:11px;color:#10b981;margin-top:4px">✋ Arraste o marcador para reposicionar</p>' : '';
          marker.bindPopup(`<div style="min-width:200px;cursor:pointer" id="popup-${c.id}"><h4 style="font-weight:bold;margin-bottom:4px">${c.name}</h4><p style="font-size:13px;color:#666;margin:2px 0">📍 ${c.location}</p><p style="font-size:13px;margin:2px 0">⭐ ${c.average_rating.toFixed(1)}/5 (${c.review_count})</p><p style="font-size:12px;color:#2563eb;margin-top:6px">Clique para ver detalhes →</p>${adminHint}</div>`);
          marker.on('popupopen', () => {
            setTimeout(() => {
              const el = document.getElementById(`popup-${c.id}`);
              if (el) el.onclick = () => navigate(`/empresa/${c.id}`);
            }, 50);
          });
        }

        markersRef.current.push(marker);
      });

      if (userPos) {
        const um = L.marker(userPos).addTo(map);
        um.bindPopup('Você está aqui!');
        markersRef.current.push(um);
      }
    });
  }, [filtered, userPos, mapReady, navigate, isAdmin, updateCompany, showToast]);

  const handleLocate = () => {
    if (!navigator.geolocation) { showToast('Geolocalização não suportada', 'error'); return; }
    showToast('Obtendo localização...', 'info');
    navigator.geolocation.getCurrentPosition(
      pos => { const p: [number, number] = [pos.coords.latitude, pos.coords.longitude]; setUserPos(p); mapInstanceRef.current?.setView(p, 12); showToast('Localização encontrada!', 'success'); },
      () => showToast('Erro ao obter localização', 'error')
    );
  };

  const legend = [
    { color: '#10b981', label: '4.5+ (Excelente)' },
    { color: '#3b82f6', label: '3.5-4.4 (Bom)' },
    { color: '#f59e0b', label: '2.5-3.4 (Regular)' },
    { color: '#dc2626', label: 'Abaixo de 2.5' },
  ];

  const filteredCluster = clusterPopup?.companies.filter(c =>
    c.name.toLowerCase().includes(clusterSearch.toLowerCase())
  ) || [];

  return (
    <div className="pt-20">
      <section className="py-8 text-center" style={{ background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)' }}>
        <div className="container mx-auto px-5">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2 flex items-center justify-center gap-3">
            <MapPin className="w-8 h-8" /> Mapa Interativo
          </h1>
          {isAdmin && (
            <p className="text-white/90 text-sm mt-2">
              👑 Modo Admin: arraste qualquer marcador para reposicionar a empresa no mapa
            </p>
          )}
        </div>
      </section>
      <section className="py-10">
        <div className="container mx-auto px-5">
          <div className="relative rounded-xl overflow-hidden shadow-xl mb-6" style={{ height: '500px' }}>
            {mapError ? (
              <div className="flex items-center justify-center h-full bg-secondary"><p className="text-muted-foreground">Erro ao carregar mapa.</p></div>
            ) : (
              <div ref={mapContainerRef} style={{ height: '100%', width: '100%' }} />
            )}
            <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
              <button onClick={handleLocate} className="flex items-center gap-2 px-4 py-2 bg-card rounded-lg shadow-md text-sm font-medium hover:bg-secondary transition-colors">
                <Crosshair className="w-4 h-4" /> Localização
              </button>
              <button onClick={() => mapInstanceRef.current?.setView([-15.793889, -47.882778], 4)} className="flex items-center gap-2 px-4 py-2 bg-card rounded-lg shadow-md text-sm font-medium hover:bg-secondary transition-colors">
                <RotateCcw className="w-4 h-4" /> Resetar
              </button>
            </div>
            <div className="absolute bottom-4 left-4 z-[1000] bg-card rounded-lg shadow-md p-3">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-muted-foreground" />
                <select value={sectorFilter} onChange={e => setSectorFilter(e.target.value)}
                  className="text-sm border border-input rounded-md px-2 py-1 bg-background text-foreground">
                  <option value="">Todos</option>
                  {['Tecnologia','Finanças','Saúde','Educação','Varejo','Energia'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Cluster popup modal */}
          {clusterPopup && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[2000] p-5" onClick={() => setClusterPopup(null)}>
              <div className="bg-card rounded-xl w-full max-w-md max-h-[80vh] flex flex-col shadow-2xl" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b border-border flex items-center justify-between shrink-0">
                  <h3 className="font-bold text-foreground flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-primary" />
                    {clusterPopup.companies.length} empresas neste local
                  </h3>
                  <button onClick={() => setClusterPopup(null)} className="p-1 hover:bg-secondary rounded-lg">
                    <X className="w-5 h-5 text-muted-foreground" />
                  </button>
                </div>
                <div className="p-3 border-b border-border shrink-0">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <input value={clusterSearch} onChange={e => setClusterSearch(e.target.value)}
                      placeholder="Buscar neste edifício..."
                      className="w-full pl-9 pr-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                  </div>
                </div>
                <div className="overflow-y-auto flex-1 p-3 space-y-2">
                  {filteredCluster.map(c => (
                    <button key={c.id} onClick={() => { setClusterPopup(null); navigate(`/empresa/${c.id}`); }}
                      className="w-full text-left p-3 bg-secondary rounded-lg hover:bg-accent transition-colors flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary text-primary-foreground rounded-lg flex items-center justify-center font-bold text-sm shrink-0">
                        {c.name.substring(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <strong className="text-foreground text-sm block truncate">{c.name}</strong>
                        <p className="text-xs text-muted-foreground">{c.sector} • ⭐ {c.average_rating.toFixed(1)}</p>
                      </div>
                    </button>
                  ))}
                  {filteredCluster.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">Nenhuma empresa encontrada</p>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="bg-card rounded-xl p-6 shadow-md mb-10">
            <h3 className="font-bold text-foreground mb-3">🗝️ Legenda</h3>
            <div className="flex flex-wrap gap-4">
              {legend.map(l => (
                <div key={l.color} className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full" style={{ backgroundColor: l.color }} />
                  <span className="text-sm text-muted-foreground">{l.label}</span>
                </div>
              ))}
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/50 flex items-center justify-center text-white text-xs font-bold">3</div>
                <span className="text-sm text-muted-foreground">Edifício comercial (múltiplas empresas)</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.slice(0, 6).map(c => (
              <div key={c.id} onClick={() => navigate(`/empresa/${c.id}`)}
                className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer border border-border">
                <div className="bg-primary text-primary-foreground p-4 flex items-center gap-3">
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center font-bold text-primary text-lg">
                    {c.name.substring(0, 2)}
                  </div>
                  <div>
                    <h4 className="font-semibold">{c.name}</h4>
                    <p className="text-sm opacity-80 flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> {c.location}
                    </p>
                  </div>
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium text-foreground">⭐ {c.average_rating.toFixed(1)}/5</span>
                    <span className="text-xs text-muted-foreground">({c.review_count} avaliações)</span>
                  </div>
                  <span className="bg-secondary text-secondary-foreground px-3 py-1 rounded-full text-xs">{c.sector}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default MapaPage;
