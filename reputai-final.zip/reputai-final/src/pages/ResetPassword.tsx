import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Lock, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToastContext } from '@/contexts/ToastContext';

const ResetPasswordPage: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToastContext();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    // Check for recovery token in URL hash
    const hash = window.location.hash;
    if (!hash.includes('type=recovery')) {
      showToast('Link de recuperação inválido', 'error');
      navigate('/');
    }
  }, [navigate, showToast]);

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) { showToast('Senha deve ter no mínimo 6 caracteres', 'error'); return; }
    if (password !== confirm) { showToast('As senhas não coincidem', 'error'); return; }

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);

    if (error) {
      showToast('Erro ao redefinir senha', 'error');
    } else {
      setDone(true);
      showToast('Senha redefinida com sucesso!', 'success');
      setTimeout(() => navigate('/'), 3000);
    }
  };

  if (done) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="bg-card p-8 rounded-xl shadow-md text-center max-w-md">
          <CheckCircle className="w-16 h-16 mx-auto text-success mb-4" />
          <h2 className="text-2xl font-bold text-foreground mb-3">Senha Redefinida!</h2>
          <p className="text-muted-foreground">Redirecionando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen flex items-center justify-center">
      <div className="bg-card p-8 rounded-xl shadow-md max-w-md w-full">
        <h2 className="text-2xl font-bold text-foreground mb-6 text-center">Redefinir Senha</h2>
        <form onSubmit={handleReset} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1 text-foreground">Nova Senha</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Mínimo 6 caracteres"
                className="w-full pl-10 pr-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1 text-foreground">Confirmar Senha</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
              <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} placeholder="Repita a senha"
                className="w-full pl-10 pr-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
            </div>
          </div>
          <button type="submit" disabled={loading}
            className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 disabled:opacity-50">
            {loading ? 'Redefinindo...' : 'Redefinir Senha'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ResetPasswordPage;
