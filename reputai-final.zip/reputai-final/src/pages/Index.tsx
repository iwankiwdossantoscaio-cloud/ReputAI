import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MapPin, Star, Search, Laptop, TrendingUp, Heart, GraduationCap, ShoppingCart, UserCheck, BarChart3, Shield, UserX, Ban, Building2, CheckCircle } from 'lucide-react';
import logoBrain from '@/assets/logo-brain.jpg';
import { motion } from 'framer-motion';
import TypingEffect from '@/components/TypingEffect';
import CompanyCard from '@/components/CompanyCard';
import { useCompanies } from '@/hooks/useCompanies';
import { useAuth } from '@/contexts/AuthContext';

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.6 } }),
};

const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

const Index: React.FC = () => {
  const { companies } = useCompanies();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [search, setSearch] = React.useState('');

  const filtered = search
    ? companies.filter(c =>
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.sector.toLowerCase().includes(search.toLowerCase()) ||
        c.location.toLowerCase().includes(search.toLowerCase())
      )
    : companies.slice(0, 4);

  const sectorFilters = [
    { name: 'Tecnologia', icon: Laptop },
    { name: 'Finanças', icon: TrendingUp },
    { name: 'Saúde', icon: Heart },
    { name: 'Educação', icon: GraduationCap },
    { name: 'Varejo', icon: ShoppingCart },
  ];

  const steps = [
    { num: 1, icon: UserCheck, title: 'Crie sua Conta', desc: 'Faça login ou cadastre-se gratuitamente para acessar todas as funcionalidades.', items: ['Cadastro rápido e seguro', 'Dados protegidos', 'Acesso imediato'] },
    { num: 2, icon: Star, title: 'Avalie Empresas', desc: 'Compartilhe sua experiência real de trabalho em empresas brasileiras.', items: ['Baseado em experiência real', 'Sistema de 1-5 estrelas', 'Comentários detalhados'] },
    { num: 3, icon: BarChart3, title: 'Consulte Avaliações', desc: 'Encontre as melhores empresas para trabalhar baseado em avaliações reais.', items: ['Mapa interativo', 'Filtros por setor', 'Busca inteligente'] },
  ];

  const policies = [
    { icon: Shield, title: 'Avaliações Verificadas', desc: 'Todas as avaliações são feitas por usuários registrados.' },
    { icon: UserX, title: 'Experiência Real', desc: 'Exigimos experiência pessoal real de trabalho.' },
    { icon: Ban, title: 'Sem Cópias', desc: 'Não permitimos avaliações copiadas de outros sites.' },
    { icon: Building2, title: 'Cadastro Automático', desc: 'Empresas são cadastradas automaticamente com sua avaliação.' },
  ];

  const getProtectedPath = (path: string) => (currentUser ? path : '/');

  return (
    <div className="w-full overflow-x-hidden">
      {/* Hero */}
      <section className="min-h-[100svh] flex items-center pt-20 pb-12 md:pt-24 md:pb-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-[hsl(var(--primary))]" />
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40"
          style={{ backgroundImage: `url(${logoBrain})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/60" />
        <div className="container mx-auto px-4 w-full relative z-10">
          <motion.div className="max-w-3xl mx-auto text-center text-white" initial="hidden" animate="visible" variants={stagger}>
            <motion.h2 variants={fadeUp} custom={0} className="text-2xl sm:text-3xl md:text-5xl font-bold mb-4 md:mb-6 leading-tight">
              <span className="block mb-1">Encontre</span>
              <span className="block h-[1.3em]"><TypingEffect /></span>
              <span className="block mt-1">para trabalhar</span>
            </motion.h2>
            <motion.p variants={fadeUp} custom={1} className="text-base md:text-xl opacity-90 mb-6 md:mb-8 px-2">
              Avaliações reais de ex-funcionários para você tomar a decisão certa na sua carreira.
            </motion.p>

            <motion.div variants={fadeUp} custom={2} className="bg-white rounded-xl p-3 md:p-4 shadow-xl max-w-2xl mx-auto mb-4 md:mb-6">
              <div className="flex flex-col sm:flex-row gap-2">
                <input type="text" value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Empresa, setor ou localização..."
                  className="flex-1 px-3 py-2.5 md:px-4 md:py-3 border-2 border-border rounded-lg text-foreground bg-background focus:border-primary focus:outline-none text-sm md:text-base" />
                <button className="px-5 py-2.5 md:px-6 md:py-3 bg-primary text-primary-foreground rounded-lg font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity whitespace-nowrap text-sm md:text-base">
                  <Search className="w-4 h-4" /> Buscar
                </button>
              </div>
            </motion.div>

            <motion.div variants={fadeUp} custom={3} className="flex flex-wrap gap-2 justify-center mb-6 md:mb-8 px-2">
              {sectorFilters.map(f => (
                <button key={f.name} onClick={() => setSearch(f.name)}
                  className="flex items-center gap-1.5 px-3 py-1.5 md:px-4 md:py-2 bg-white/20 rounded-full text-xs md:text-sm hover:bg-white/30 transition-colors">
                  <f.icon className="w-3.5 h-3.5 md:w-4 md:h-4" /> {f.name}
                </button>
              ))}
            </motion.div>

            <motion.div variants={fadeUp} custom={4} className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center px-4">
              <Link to={getProtectedPath('/mapa')} className="px-5 py-2.5 md:px-6 md:py-3 bg-white text-primary rounded-xl font-semibold flex items-center justify-center gap-2 hover:-translate-y-0.5 hover:shadow-lg transition-all text-sm md:text-base">
                <MapPin className="w-4 h-4 md:w-5 md:h-5" /> Explorar Mapa
              </Link>
              <Link to={getProtectedPath('/avaliacao')} className="px-5 py-2.5 md:px-6 md:py-3 border-2 border-white text-white rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-white hover:text-primary transition-all text-sm md:text-base">
                <Star className="w-4 h-4 md:w-5 md:h-5" /> Compartilhar Experiência
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Companies */}
      <section className="py-20">
        <div className="container mx-auto px-5">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3 flex items-center justify-center gap-3">
              <Building2 className="w-8 h-8 text-primary" /> Empresas em Destaque
            </h2>
            <p className="text-muted-foreground text-lg">Conheça empresas bem avaliadas por funcionários</p>
          </motion.div>
          <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
            {filtered.map((company, i) => (
              <motion.div key={company.id} variants={fadeUp} custom={i}>
                <CompanyCard company={company} onClick={() => navigate(`/empresa/${company.id}`)} />
              </motion.div>
            ))}
          </motion.div>
          <div className="text-center mt-12">
            <Link to={getProtectedPath('/empresas')} className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:opacity-90 transition-opacity">
              <Building2 className="w-5 h-5" /> Ver Todas as Empresas
            </Link>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 bg-secondary">
        <div className="container mx-auto px-5">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-3">Como Funciona</h2>
            <p className="text-muted-foreground text-lg">Entenda em 3 passos simples</p>
          </motion.div>
          <motion.div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
            {steps.map((step, i) => (
              <motion.div key={step.num} variants={fadeUp} custom={i}
                className="bg-card p-8 rounded-xl shadow-md text-center relative border-t-4 border-primary hover:-translate-y-2 transition-transform">
                <div className="absolute -top-5 left-1/2 -translate-x-1/2 w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold shadow-lg">
                  {step.num}
                </div>
                <div className="mt-4 mb-4"><step.icon className="w-12 h-12 mx-auto text-primary" /></div>
                <h3 className="text-xl font-bold text-foreground mb-3">{step.title}</h3>
                <p className="text-muted-foreground mb-4">{step.desc}</p>
                <ul className="text-left space-y-2">
                  {step.items.map(item => (
                    <li key={item} className="flex items-center gap-2 text-sm text-foreground">
                      <CheckCircle className="w-4 h-4 text-success shrink-0" /> {item}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>

          <motion.div className="bg-card p-8 rounded-xl shadow-md" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
            <h3 className="text-2xl font-bold text-center text-foreground mb-8">Política de Avaliações</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {policies.map((p, i) => (
                <motion.div key={i} variants={fadeUp} custom={i}
                  className="text-center p-6 bg-secondary rounded-xl hover:-translate-y-1 hover:shadow-md transition-all">
                  <p.icon className={`w-10 h-10 mx-auto mb-4 ${i === 0 ? 'text-primary' : i === 1 ? 'text-success' : i === 2 ? 'text-destructive' : 'text-warning'}`} />
                  <h4 className="font-bold text-foreground mb-2">{p.title}</h4>
                  <p className="text-sm text-muted-foreground">{p.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <div className="mt-8 text-center p-8 rounded-xl text-white" style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)' }}>
            <h3 className="text-xl font-bold mb-3"><Star className="w-5 h-5 inline mr-2" /> Quer avaliar uma empresa?</h3>
            <p className="opacity-90 mb-6">Clique no botão abaixo para compartilhar sua experiência.</p>
             <Link to={getProtectedPath('/avaliacao')} className="inline-flex items-center gap-2 px-6 py-3 bg-white text-warning rounded-xl font-semibold hover:-translate-y-0.5 transition-transform">
              <Star className="w-5 h-5" /> Ir para Página de Avaliação
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
