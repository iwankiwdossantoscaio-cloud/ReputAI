import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Crown, Users, Building2, Star, AlertTriangle, Trash2,
  CheckCircle, XCircle, Shield, UserCheck, UserX, Clock, Bell, BellOff, Plus, MapPin, Edit2, Eye, EyeOff, Phone, Globe, Mail, Save
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useCompanies } from '@/hooks/useCompanies';
import { useToastContext } from '@/contexts/ToastContext';

const AdminPage: React.FC = () => {
  const { currentUser, isAdmin, promoteToAdmin, demoteFromAdmin, getAllUsers } = useAuth();
  const {
    companies, evaluations, notifications, deleteCompany, deleteEvaluation,
    approveEvaluation, rejectEvaluation, markNotificationRead, addCompany, updateCompany,
  } = useCompanies();
  const { showToast } = useToastContext();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'overview' | 'evaluations' | 'users' | 'flagged' | 'notifications' | 'add-company'>('overview');
  const [users, setUsers] = useState<any[]>([]);
  const [showAnonymous, setShowAnonymous] = useState<Record<string, boolean>>({});

  // New company form
  const [newName, setNewName] = useState('');
  const [newSector, setNewSector] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newLat, setNewLat] = useState('');
  const [newLng, setNewLng] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newWebsite, setNewWebsite] = useState('');
  const [newCnpj, setNewCnpj] = useState('');
  const [addingCompany, setAddingCompany] = useState(false);

  // Edit company location
  const [editingCompany, setEditingCompany] = useState<string | null>(null);
  const [editLat, setEditLat] = useState('');
  const [editLng, setEditLng] = useState('');
  const [editLocation, setEditLocation] = useState('');

  useEffect(() => {
    if (!currentUser || !isAdmin) {
      showToast('Acesso restrito a administradores', 'error');
      navigate('/');
    }
  }, [currentUser, isAdmin, navigate, showToast]);

  useEffect(() => {
    if (isAdmin) {
      getAllUsers().then(setUsers);
    }
  }, [isAdmin, getAllUsers]);

  if (!isAdmin) return null;

  const pendingEvals = evaluations.filter(e => e.status === 'pending');
  const flaggedEvals = evaluations.filter(e => e.flagged_profanity && e.status === 'pending');
  const unreadNotifs = notifications.filter(n => !n.is_read);

  const getCompanyName = (companyId: string) => companies.find(c => c.id === companyId)?.name || 'Desconhecida';

  // Get real author for anonymous evals - admin can see user_id
  const getRealAuthor = (ev: any) => {
    const profile = users.find(u => u.user_id === ev.user_id);
    return profile ? `${profile.name} (${profile.email})` : ev.user_id;
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, { bg: string; text: string; label: string }> = {
      pending: { bg: 'bg-warning/20', text: 'text-warning', label: '⏳ Pendente' },
      approved: { bg: 'bg-success/20', text: 'text-success', label: '✅ Aprovada' },
      rejected: { bg: 'bg-destructive/20', text: 'text-destructive', label: '❌ Rejeitada' },
    };
    const s = map[status] || map.pending;
    return <span className={`${s.bg} ${s.text} px-2 py-1 rounded-full text-xs font-medium`}>{s.label}</span>;
  };

  const handleAddCompany = async () => {
    if (!newName.trim()) { showToast('Nome é obrigatório', 'error'); return; }
    setAddingCompany(true);
    const result = await addCompany({
      name: newName,
      sector: newSector || 'Outros',
      location: newLocation || 'Brasil',
      description: newDescription || `Empresa cadastrada pelo admin`,
      lat: newLat ? parseFloat(newLat) : -15 + (Math.random() - 0.5) * 20,
      lng: newLng ? parseFloat(newLng) : -50 + (Math.random() - 0.5) * 20,
      average_rating: 0,
      review_count: 0,
      phone: newPhone,
      email: newEmail,
      website: newWebsite,
      cnpj: newCnpj,
    });
    setAddingCompany(false);
    if (result) {
      showToast(`Empresa "${newName}" cadastrada com sucesso!`, 'success');
      setNewName(''); setNewSector(''); setNewLocation(''); setNewDescription(''); setNewLat(''); setNewLng('');
      setNewPhone(''); setNewEmail(''); setNewWebsite(''); setNewCnpj('');
    } else {
      showToast('Erro ao cadastrar empresa', 'error');
    }
  };

  const handleUpdateLocation = async (companyId: string) => {
    const updates: any = {};
    if (editLat) updates.lat = parseFloat(editLat);
    if (editLng) updates.lng = parseFloat(editLng);
    if (editLocation) updates.location = editLocation;
    const ok = await updateCompany(companyId, updates);
    if (ok) {
      showToast('Localização atualizada!', 'success');
      setEditingCompany(null);
    } else {
      showToast('Erro ao atualizar', 'error');
    }
  };

  const stats = [
    { icon: Users, value: users.length, label: 'Usuários', color: 'from-primary to-blue-700' },
    { icon: Building2, value: companies.length, label: 'Empresas', color: 'from-success to-emerald-700' },
    { icon: Star, value: evaluations.length, label: 'Avaliações', color: 'from-warning to-amber-700' },
    { icon: Clock, value: pendingEvals.length, label: 'Pendentes', color: 'from-orange-500 to-orange-700' },
    { icon: AlertTriangle, value: flaggedEvals.length, label: 'Suspeitas', color: 'from-yellow-500 to-yellow-700' },
    { icon: Bell, value: unreadNotifs.length, label: 'Notificações', color: 'from-purple-500 to-purple-700' },
  ];

  const tabs = [
    { id: 'overview' as const, label: 'Visão Geral', icon: Crown },
    { id: 'evaluations' as const, label: `Avaliações (${pendingEvals.length})`, icon: Star },
    { id: 'flagged' as const, label: `Suspeitas (${flaggedEvals.length})`, icon: AlertTriangle },
    { id: 'users' as const, label: `Usuários (${users.length})`, icon: Users },
    { id: 'notifications' as const, label: `Notificações (${unreadNotifs.length})`, icon: Bell },
    { id: 'add-company' as const, label: 'Cadastrar Empresa', icon: Plus },
  ];

  return (
    <div className="pt-20">
      <section className="py-8" style={{ background: 'linear-gradient(135deg, #1e293b 0%, #334155 100%)' }}>
        <div className="container mx-auto px-5">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center gap-3">
            <Crown className="w-8 h-8 text-yellow-400" /> Painel Administrativo
          </h1>
          <p className="text-white/70">Gerencie usuários, avaliações e empresas</p>
          <div className="flex items-center gap-2 mt-3">
            <Shield className="w-4 h-4 text-green-400" />
            <span className="text-green-400 text-sm font-medium">Admin verificado • {currentUser?.email}</span>
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="container mx-auto px-5 space-y-8">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {stats.map((s, i) => (
              <div key={i} className={`bg-gradient-to-br ${s.color} text-white p-5 rounded-xl text-center shadow-lg`}>
                <s.icon className="w-7 h-7 mx-auto mb-2 opacity-80" />
                <div className="text-2xl font-bold">{s.value}</div>
                <div className="text-xs opacity-80">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-2 border-b border-border pb-4">
            {tabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === tab.id ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground hover:bg-accent'}`}>
                <tab.icon className="w-4 h-4" /> {tab.label}
              </button>
            ))}
          </div>

          {/* Overview */}
          {activeTab === 'overview' && (
            <div className="bg-card p-6 rounded-xl shadow-md">
              <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2"><Building2 className="w-5 h-5" /> Empresas ({companies.length})</h3>
              <div className="space-y-3">
                {companies.map(c => (
                  <div key={c.id} className="p-4 bg-secondary rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary text-primary-foreground rounded-lg flex items-center justify-center font-bold text-sm">{c.name.substring(0, 2)}</div>
                        <div>
                          <strong className="text-foreground text-sm">{c.name}</strong>
                          <p className="text-xs text-muted-foreground">{c.sector} • {c.location} • {c.average_rating.toFixed(1)}/5</p>
                          <p className="text-xs text-muted-foreground">Lat: {c.lat.toFixed(4)} • Lng: {c.lng.toFixed(4)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => {
                          setEditingCompany(editingCompany === c.id ? null : c.id);
                          setEditLat(c.lat.toString());
                          setEditLng(c.lng.toString());
                          setEditLocation(c.location);
                        }} className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors" title="Editar localização">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => { if (confirm('Remover empresa?')) deleteCompany(c.id); }}
                          className="p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                    {editingCompany === c.id && (
                      <div className="mt-3 p-3 bg-card rounded-lg border border-border space-y-3">
                        <h4 className="text-sm font-medium text-foreground flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" /> Editar Localização</h4>
                        <div>
                          <label className="block text-xs font-medium mb-1 text-foreground">Endereço</label>
                          <input value={editLocation} onChange={e => setEditLocation(e.target.value)}
                            className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-medium mb-1 text-foreground">Latitude</label>
                            <input value={editLat} onChange={e => setEditLat(e.target.value)} type="number" step="any"
                              className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                          </div>
                          <div>
                            <label className="block text-xs font-medium mb-1 text-foreground">Longitude</label>
                            <input value={editLng} onChange={e => setEditLng(e.target.value)} type="number" step="any"
                              className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                          </div>
                        </div>
                        <button onClick={() => handleUpdateLocation(c.id)}
                          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90">
                          <Save className="w-4 h-4" /> Salvar Localização
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Evaluations */}
          {activeTab === 'evaluations' && (
            <div className="space-y-6">
              <div className="bg-card p-6 rounded-xl shadow-md">
                <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-warning" /> Pendentes ({pendingEvals.length})
                </h3>
                {pendingEvals.length === 0 ? (
                  <p className="text-muted-foreground text-sm py-4 text-center">Nenhuma pendente 🎉</p>
                ) : (
                  <div className="space-y-3">
                    {pendingEvals.map(ev => (
                      <EvalCard key={ev.id} ev={ev} companyName={getCompanyName(ev.company_id)} statusBadge={getStatusBadge(ev.status)}
                        showAnonymousId={showAnonymous[ev.id]} realAuthor={getRealAuthor(ev)}
                        onToggleAnonymous={() => setShowAnonymous(prev => ({ ...prev, [ev.id]: !prev[ev.id] }))}
                        onApprove={() => { approveEvaluation(ev.id); showToast('Aprovada', 'success'); }}
                        onReject={() => { rejectEvaluation(ev.id); showToast('Rejeitada', 'info'); }}
                        onDelete={() => { if (confirm('Excluir?')) { deleteEvaluation(ev.id); showToast('Excluída', 'success'); } }} />
                    ))}
                  </div>
                )}
              </div>
              <div className="bg-card p-6 rounded-xl shadow-md">
                <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2"><Star className="w-5 h-5" /> Todas ({evaluations.length})</h3>
                <div className="space-y-3">
                  {evaluations.map(ev => (
                    <EvalCard key={ev.id} ev={ev} companyName={getCompanyName(ev.company_id)} statusBadge={getStatusBadge(ev.status)}
                      showAnonymousId={showAnonymous[ev.id]} realAuthor={getRealAuthor(ev)}
                      onToggleAnonymous={() => setShowAnonymous(prev => ({ ...prev, [ev.id]: !prev[ev.id] }))}
                      onApprove={ev.status !== 'approved' ? () => { approveEvaluation(ev.id); showToast('Aprovada', 'success'); } : undefined}
                      onReject={ev.status !== 'rejected' ? () => { rejectEvaluation(ev.id); showToast('Rejeitada', 'info'); } : undefined}
                      onDelete={() => { if (confirm('Excluir?')) { deleteEvaluation(ev.id); showToast('Excluída', 'success'); } }} />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Flagged */}
          {activeTab === 'flagged' && (
            <div className="bg-card p-6 rounded-xl shadow-md">
              <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-warning" /> Suspeitas ({flaggedEvals.length})
              </h3>
              {flaggedEvals.length === 0 ? (
                <p className="text-muted-foreground text-sm py-4 text-center">Nenhuma suspeita 🎉</p>
              ) : (
                <div className="space-y-3">
                  {flaggedEvals.map(ev => (
                    <div key={ev.id} className="p-4 bg-secondary rounded-lg border-l-4 border-warning">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <strong className="text-foreground text-sm">{getCompanyName(ev.company_id)}</strong>
                          <p className="text-xs text-muted-foreground">por {ev.user_name} • {new Date(ev.date).toLocaleDateString('pt-BR')}</p>
                          {ev.anonymous && (
                            <p className="text-xs text-primary mt-1">👁️ Autor real: {getRealAuthor(ev)}</p>
                          )}
                        </div>
                        <span className="bg-warning/20 text-warning px-2 py-1 rounded-full text-xs font-medium">⚠️ Suspeita</span>
                      </div>
                      <p className="text-sm text-foreground mb-3 bg-card p-3 rounded-lg">"{ev.text}"</p>
                      <div className="flex gap-2">
                        <button onClick={() => { approveEvaluation(ev.id); showToast('Aprovada', 'success'); }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-success text-white rounded-lg text-xs font-medium hover:opacity-90">
                          <CheckCircle className="w-3 h-3" /> Aprovar
                        </button>
                        <button onClick={() => { rejectEvaluation(ev.id); showToast('Rejeitada', 'info'); }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-warning text-white rounded-lg text-xs font-medium hover:opacity-90">
                          <XCircle className="w-3 h-3" /> Rejeitar
                        </button>
                        <button onClick={() => { if (confirm('Excluir?')) { deleteEvaluation(ev.id); showToast('Excluída', 'success'); } }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-destructive/10 text-destructive rounded-lg text-xs font-medium hover:bg-destructive/20">
                          <Trash2 className="w-3 h-3" /> Excluir
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Users */}
          {activeTab === 'users' && (
            <div className="bg-card p-6 rounded-xl shadow-md">
              <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2"><Users className="w-5 h-5" /> Usuários ({users.length})</h3>
              <div className="space-y-3">
                {users.map((u: any) => (
                  <div key={u.user_id} className="flex items-center justify-between p-4 bg-secondary rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white text-sm ${u.isAdmin ? 'bg-gradient-to-br from-destructive to-red-700' : 'bg-gradient-to-br from-primary to-blue-700'}`}>
                        {u.name?.charAt(0).toUpperCase() || '?'}
                      </div>
                      <div>
                        <strong className="text-foreground text-sm flex items-center gap-2">
                          {u.name} {u.isAdmin && <Crown className="w-3 h-3 text-warning" />}
                        </strong>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {u.isAdmin ? (
                        <button onClick={async () => {
                          if (u.user_id === currentUser?.id) { showToast('Você não pode remover seu próprio acesso admin', 'error'); return; }
                          if (confirm(`Remover admin de ${u.name}?`)) {
                            await demoteFromAdmin(u.user_id);
                            const updated = await getAllUsers();
                            setUsers(updated);
                            showToast('Admin removido', 'info');
                          }
                        }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-destructive/10 text-destructive rounded-lg text-xs font-medium hover:bg-destructive/20">
                          <UserX className="w-3 h-3" /> Remover Admin
                        </button>
                      ) : (
                        <button onClick={async () => {
                          if (confirm(`Promover ${u.name}?`)) {
                            await promoteToAdmin(u.user_id);
                            const updated = await getAllUsers();
                            setUsers(updated);
                            showToast('Promovido!', 'success');
                          }
                        }}
                          className="flex items-center gap-1 px-3 py-1.5 bg-success/10 text-success rounded-lg text-xs font-medium hover:bg-success/20">
                          <UserCheck className="w-3 h-3" /> Promover
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notifications */}
          {activeTab === 'notifications' && (
            <div className="bg-card p-6 rounded-xl shadow-md">
              <h3 className="text-lg font-bold text-foreground mb-4 flex items-center gap-2">
                <Bell className="w-5 h-5 text-purple-500" /> Notificações ({notifications.length})
              </h3>
              {notifications.length === 0 ? (
                <p className="text-muted-foreground text-sm py-4 text-center">Nenhuma notificação</p>
              ) : (
                <div className="space-y-3">
                  {notifications.map(n => (
                    <div key={n.id} className={`p-4 rounded-lg flex items-start justify-between gap-3 ${n.is_read ? 'bg-secondary' : 'bg-primary/5 border border-primary/20'}`}>
                      <div className="flex items-start gap-3">
                        {n.type === 'flagged_evaluation' ? (
                          <AlertTriangle className="w-5 h-5 text-warning shrink-0 mt-0.5" />
                        ) : (
                          <Bell className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="text-sm font-medium text-foreground">{n.title}</p>
                          <p className="text-xs text-muted-foreground">{n.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">{new Date(n.created_at).toLocaleString('pt-BR')}</p>
                        </div>
                      </div>
                      {!n.is_read && (
                        <button onClick={() => markNotificationRead(n.id)}
                          className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-secondary rounded-lg transition-colors" title="Marcar como lida">
                          <BellOff className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Add Company */}
          {activeTab === 'add-company' && (
            <div className="bg-card p-6 rounded-xl shadow-md max-w-2xl">
              <h3 className="text-lg font-bold text-foreground mb-6 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-primary" /> Cadastrar Nova Empresa
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1 text-foreground">Nome da Empresa *</label>
                  <input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Nome da empresa"
                    className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1 text-foreground">Setor</label>
                    <select value={newSector} onChange={e => setNewSector(e.target.value)}
                      className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none">
                      <option value="">Selecione</option>
                      {['Tecnologia','Finanças','Saúde','Varejo','Serviços','Energia','Educação','Indústria','Construção Civil','Agronegócio','Outros'].map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1 text-foreground flex items-center gap-1">
                      <MapPin className="w-4 h-4 text-primary" /> Endereço / Localização *
                    </label>
                    <input value={newLocation} onChange={e => setNewLocation(e.target.value)} placeholder="Cole o endereço completo"
                      className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-foreground">Descrição</label>
                  <textarea value={newDescription} onChange={e => setNewDescription(e.target.value)} rows={3} placeholder="Breve descrição da empresa"
                    className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none resize-y" />
                </div>

                {/* Company details */}
                <div className="bg-secondary p-4 rounded-lg">
                  <h4 className="text-sm font-medium text-foreground mb-3">Informações adicionais (opcional)</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium mb-1 text-foreground flex items-center gap-1"><Phone className="w-3 h-3" /> Telefone</label>
                      <input value={newPhone} onChange={e => setNewPhone(e.target.value)} placeholder="(11) 99999-9999"
                        className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium mb-1 text-foreground flex items-center gap-1"><Mail className="w-3 h-3" /> Email</label>
                      <input value={newEmail} onChange={e => setNewEmail(e.target.value)} placeholder="contato@empresa.com"
                        className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium mb-1 text-foreground flex items-center gap-1"><Globe className="w-3 h-3" /> Website</label>
                      <input value={newWebsite} onChange={e => setNewWebsite(e.target.value)} placeholder="www.empresa.com.br"
                        className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium mb-1 text-foreground">CNPJ</label>
                      <input value={newCnpj} onChange={e => setNewCnpj(e.target.value)} placeholder="00.000.000/0001-00"
                        className="w-full px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1 text-foreground">Latitude (opcional)</label>
                    <input value={newLat} onChange={e => setNewLat(e.target.value)} placeholder="Ex: -23.5505" type="number" step="any"
                      className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1 text-foreground">Longitude (opcional)</label>
                    <input value={newLng} onChange={e => setNewLng(e.target.value)} placeholder="Ex: -46.6333" type="number" step="any"
                      className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">💡 Se não informar lat/lng, a empresa será posicionada aleatoriamente no mapa.</p>
                <button onClick={handleAddCompany} disabled={addingCompany}
                  className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-50">
                  <Plus className="w-5 h-5" /> {addingCompany ? 'Cadastrando...' : 'Cadastrar Empresa'}
                </button>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

// Eval card sub-component
const EvalCard: React.FC<{
  ev: any; companyName: string; statusBadge: React.ReactNode;
  showAnonymousId?: boolean; realAuthor?: string;
  onToggleAnonymous?: () => void;
  onApprove?: () => void; onReject?: () => void; onDelete: () => void;
}> = ({ ev, companyName, statusBadge, showAnonymousId, realAuthor, onToggleAnonymous, onApprove, onReject, onDelete }) => (
  <div className="p-4 bg-secondary rounded-lg">
    <div className="flex justify-between items-start mb-2">
      <div>
        <strong className="text-foreground text-sm">{companyName}</strong>
        <p className="text-xs text-muted-foreground">
          por {ev.user_name} • {new Date(ev.date).toLocaleDateString('pt-BR')}
          {ev.anonymous && (
            <button onClick={onToggleAnonymous} className="ml-2 text-primary hover:underline inline-flex items-center gap-1">
              {showAnonymousId ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
              {showAnonymousId ? 'Ocultar' : 'Ver autor'}
            </button>
          )}
        </p>
        {ev.anonymous && showAnonymousId && (
          <p className="text-xs text-primary mt-1 bg-primary/10 px-2 py-1 rounded">👁️ {realAuthor}</p>
        )}
      </div>
      <div className="flex items-center gap-2">
        {statusBadge}
        {ev.flagged_profanity && <span className="bg-warning/20 text-warning px-2 py-0.5 rounded-full text-xs">⚠️</span>}
      </div>
    </div>
    <p className="text-sm text-foreground mb-3">"{ev.text}"</p>
    <div className="flex gap-2">
      {onApprove && (
        <button onClick={onApprove} className="flex items-center gap-1 px-3 py-1.5 bg-success text-white rounded-lg text-xs font-medium hover:opacity-90">
          <CheckCircle className="w-3 h-3" /> Aprovar
        </button>
      )}
      {onReject && (
        <button onClick={onReject} className="flex items-center gap-1 px-3 py-1.5 bg-warning text-white rounded-lg text-xs font-medium hover:opacity-90">
          <XCircle className="w-3 h-3" /> Rejeitar
        </button>
      )}
      <button onClick={onDelete} className="flex items-center gap-1 px-3 py-1.5 bg-destructive/10 text-destructive rounded-lg text-xs font-medium hover:bg-destructive/20">
        <Trash2 className="w-3 h-3" /> Excluir
      </button>
    </div>
  </div>
);

export default AdminPage;
