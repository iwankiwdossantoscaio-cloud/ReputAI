import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Save, Star, Trash2, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useCompanies } from '@/hooks/useCompanies';
import { useToastContext } from '@/contexts/ToastContext';
import { StarDisplay } from '@/components/CompanyCard';

const PerfilPage: React.FC = () => {
  const { currentUser, updateProfile } = useAuth();
  const { companies, evaluations, deleteEvaluation } = useCompanies();
  const { showToast } = useToastContext();
  const navigate = useNavigate();

  const [name, setName] = useState('');

  useEffect(() => {
    if (!currentUser) {
      showToast('Faça login para acessar seu perfil', 'error');
      setTimeout(() => navigate('/'), 1500);
      return;
    }
    setName(currentUser.name);
  }, [currentUser, navigate, showToast]);

  if (!currentUser) return null;

  const userEvals = evaluations.filter(e => e.user_id === currentUser.id);

  const handleSave = async () => {
    const ok = await updateProfile({ name });
    if (ok) showToast('Perfil atualizado!', 'success');
    else showToast('Erro ao atualizar', 'error');
  };

  const handleDelete = async (id: string) => {
    if (confirm('Excluir esta avaliação?')) {
      await deleteEvaluation(id);
      showToast('Avaliação excluída', 'success');
    }
  };

  const getStatusInfo = (status?: string) => {
    switch (status) {
      case 'approved': return { icon: CheckCircle, color: 'text-success', label: 'Aprovada', bg: 'bg-success/10' };
      case 'rejected': return { icon: XCircle, color: 'text-destructive', label: 'Rejeitada', bg: 'bg-destructive/10' };
      default: return { icon: Clock, color: 'text-warning', label: 'Em análise', bg: 'bg-warning/10' };
    }
  };

  return (
    <div className="pt-20">
      <section className="py-8 text-center" style={{ background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)' }}>
        <div className="container mx-auto px-5">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-3">
            <User className="w-8 h-8" /> Meu Perfil
          </h1>
          <p className="text-white/80">Gerencie seus dados e acompanhe suas avaliações</p>
        </div>
      </section>

      <section className="py-10">
        <div className="container mx-auto px-5 max-w-2xl space-y-8">
          <div className="bg-card p-8 rounded-xl shadow-md">
            <h3 className="text-lg font-bold text-foreground mb-6">Informações Pessoais</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">Nome</label>
                <input value={name} onChange={e => setName(e.target.value)}
                  className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">Email</label>
                <input value={currentUser.email} disabled
                  className="w-full px-3 py-3 border-2 border-input rounded-lg bg-secondary text-muted-foreground" />
              </div>
              <button onClick={handleSave} className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold flex items-center justify-center gap-2 hover:opacity-90">
                <Save className="w-4 h-4" /> Salvar Alterações
              </button>
            </div>
          </div>

          <div className="bg-card p-8 rounded-xl shadow-md">
            <h3 className="text-lg font-bold text-foreground mb-6">Minhas Avaliações ({userEvals.length})</h3>
            {userEvals.length === 0 ? (
              <div className="text-center py-8">
                <Star className="w-12 h-12 mx-auto text-border mb-3" />
                <p className="text-muted-foreground">Nenhuma avaliação ainda.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {userEvals.map(ev => {
                  const company = companies.find(c => c.id === ev.company_id);
                  const statusInfo = getStatusInfo(ev.status);
                  const StatusIcon = statusInfo.icon;
                  return (
                    <div key={ev.id} className="bg-secondary p-4 rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-semibold text-foreground">{company?.name || 'Desconhecida'}</h4>
                        <div className="flex items-center gap-2">
                          <span className={`${statusInfo.bg} ${statusInfo.color} px-2 py-0.5 rounded-full text-xs font-medium flex items-center gap-1`}>
                            <StatusIcon className="w-3 h-3" /> {statusInfo.label}
                          </span>
                          <StarDisplay rating={ev.rating} />
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{ev.text}</p>
                      {ev.status === 'pending' && (
                        <p className="text-xs text-warning mb-2 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Aguardando moderação
                        </p>
                      )}
                      <div className="flex justify-between items-center">
                        <small className="text-muted-foreground">{new Date(ev.date).toLocaleDateString('pt-BR')}</small>
                        <button onClick={() => handleDelete(ev.id)} className="text-destructive text-xs flex items-center gap-1 hover:opacity-70">
                          <Trash2 className="w-3 h-3" /> Excluir
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};

export default PerfilPage;
