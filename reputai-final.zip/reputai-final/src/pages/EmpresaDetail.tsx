import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Star, MessageCircle, Users, Clock, ThumbsUp, Send, Trash2, Phone, Globe, Mail } from 'lucide-react';
import { useCompanies } from '@/hooks/useCompanies';
import { useAuth } from '@/contexts/AuthContext';
import { useToastContext } from '@/contexts/ToastContext';

const StarDisplay: React.FC<{ rating: number }> = ({ rating }) => (
  <div className="flex items-center gap-1">
    {[1, 2, 3, 4, 5].map(i => (
      <Star key={i} className={`w-5 h-5 ${i <= Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-border'}`} />
    ))}
  </div>
);

const EmpresaDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { companies, evaluations, comments, likes, addComment, deleteComment, toggleLike } = useCompanies();
  const { currentUser } = useAuth();
  const { showToast } = useToastContext();
  const [commentTexts, setCommentTexts] = useState<Record<string, string>>({});

  const company = companies.find(c => c.id === id);
  const companyEvals = evaluations.filter(e => e.company_id === id && e.status === 'approved');

  const handleComment = async (evalId: string) => {
    const text = commentTexts[evalId]?.trim();
    if (!text) return;
    if (!currentUser) { showToast('Faça login para comentar', 'info'); return; }
    const ok = await addComment(evalId, currentUser.id, currentUser.name, text);
    if (ok) {
      setCommentTexts(prev => ({ ...prev, [evalId]: '' }));
    }
  };

  const handleLike = async (evalId: string) => {
    if (!currentUser) { showToast('Faça login para curtir', 'info'); return; }
    await toggleLike(evalId, currentUser.id);
  };

  if (!company) {
    return (
      <div className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-5 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">Empresa não encontrada</h2>
            <Link to="/empresas" className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium">
              <ArrowLeft className="w-4 h-4" /> Voltar
            </Link>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="py-8" style={{ background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)' }}>
        <div className="container mx-auto px-5">
          <Link to="/empresas" className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-4 text-sm">
            <ArrowLeft className="w-4 h-4" /> Voltar às empresas
          </Link>
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center font-bold text-primary text-2xl shadow-lg">
              {company.name.substring(0, 2)}
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">{company.name}</h1>
              <p className="text-white/80 flex items-center gap-2 mt-1">
                <MapPin className="w-4 h-4" /> {company.location} • {company.sector}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-8">
        <div className="container mx-auto px-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { value: company.average_rating.toFixed(1), label: 'Nota Média', icon: Star },
              { value: company.review_count, label: 'Avaliações', icon: MessageCircle },
              { value: company.sector, label: 'Setor', icon: Users },
              { value: company.location, label: 'Localização', icon: MapPin },
            ].map((s, i) => (
              <div key={i} className="bg-card p-4 rounded-xl shadow-sm text-center">
                <s.icon className="w-6 h-6 mx-auto text-primary mb-2" />
                <div className="text-2xl font-bold text-foreground">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Company details */}
          {(company.phone || company.email || company.website || company.cnpj) && (
            <div className="bg-card p-5 rounded-xl shadow-sm mb-6 border border-border">
              <h3 className="font-bold text-foreground mb-3">Informações da Empresa</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {company.phone && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4 text-primary" /> {company.phone}
                  </div>
                )}
                {company.email && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="w-4 h-4 text-primary" /> {company.email}
                  </div>
                )}
                {company.website && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Globe className="w-4 h-4 text-primary" />
                    <a href={company.website.startsWith('http') ? company.website : `https://${company.website}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                      {company.website}
                    </a>
                  </div>
                )}
                {company.cnpj && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    CNPJ: {company.cnpj}
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex items-center gap-3 mb-2">
            <StarDisplay rating={company.average_rating} />
            <span className="text-lg font-bold text-foreground">{company.average_rating.toFixed(1)}/5</span>
          </div>
          <p className="text-muted-foreground mb-8">{company.description || 'Empresa cadastrada na plataforma ReputAí'}</p>

          <h3 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-primary" /> Avaliações ({companyEvals.length})
          </h3>

          {companyEvals.length === 0 ? (
            <div className="bg-card p-8 rounded-xl shadow-sm text-center">
              <MessageCircle className="w-12 h-12 mx-auto text-border mb-3" />
              <p className="text-muted-foreground mb-4">Nenhuma avaliação aprovada ainda.</p>
              <Link to={`/avaliacao?company=${encodeURIComponent(company.name)}`}
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium">
                <Star className="w-4 h-4" /> Seja o primeiro a avaliar
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {companyEvals.map(ev => {
                const evalComments = comments.filter(c => c.evaluation_id === ev.id);
                const evalLikes = likes.filter(l => l.evaluation_id === ev.id);
                const userLiked = currentUser ? evalLikes.some(l => l.user_id === currentUser.id) : false;
                const displayName = ev.anonymous ? 'Anônimo' : ev.user_name;

                return (
                  <div key={ev.id} className="bg-card p-5 rounded-xl shadow-sm border border-border">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center font-bold text-sm">
                          {displayName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <strong className="text-foreground text-sm">{displayName}</strong>
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {new Date(ev.date).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map(i => (
                          <Star key={i} className={`w-4 h-4 ${i <= ev.rating ? 'fill-yellow-400 text-yellow-400' : 'text-border'}`} />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-foreground leading-relaxed">{ev.text}</p>
                    {ev.ambient && (
                      <p className="text-xs text-muted-foreground mt-2">Ambiente: {ev.ambient}</p>
                    )}
                    {ev.benefits && ev.benefits.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {ev.benefits.map((b, i) => (
                          <span key={i} className="bg-secondary text-secondary-foreground px-2 py-0.5 rounded-full text-xs">{b}</span>
                        ))}
                      </div>
                    )}

                    {/* Like + Comment actions */}
                    <div className="flex items-center gap-4 mt-4 pt-3 border-t border-border">
                      <button onClick={() => handleLike(ev.id)}
                        className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${userLiked ? 'text-primary' : 'text-muted-foreground hover:text-primary'}`}>
                        <ThumbsUp className={`w-4 h-4 ${userLiked ? 'fill-primary' : ''}`} />
                        {evalLikes.length > 0 && evalLikes.length}
                      </button>
                      <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <MessageCircle className="w-4 h-4" /> {evalComments.length}
                      </span>
                    </div>

                    {/* Comments */}
                    {evalComments.length > 0 && (
                      <div className="mt-3 space-y-2 pl-4 border-l-2 border-border">
                        {evalComments.map(c => (
                          <div key={c.id} className="flex items-start justify-between gap-2">
                            <div>
                              <span className="text-xs font-medium text-foreground">{c.user_name}</span>
                              <span className="text-xs text-muted-foreground ml-2">{new Date(c.created_at).toLocaleDateString('pt-BR')}</span>
                              <p className="text-sm text-foreground">{c.text}</p>
                            </div>
                            {currentUser && c.user_id === currentUser.id && (
                              <button onClick={() => deleteComment(c.id)} className="text-muted-foreground hover:text-destructive shrink-0">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Add comment */}
                    {currentUser && (
                      <div className="flex gap-2 mt-3">
                        <input
                          value={commentTexts[ev.id] || ''}
                          onChange={e => setCommentTexts(prev => ({ ...prev, [ev.id]: e.target.value }))}
                          placeholder="Escreva um comentário..."
                          className="flex-1 px-3 py-2 border border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none"
                          onKeyDown={e => e.key === 'Enter' && handleComment(ev.id)}
                        />
                        <button onClick={() => handleComment(ev.id)} className="p-2 bg-primary text-primary-foreground rounded-lg hover:opacity-90">
                          <Send className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          <div className="text-center mt-8">
            <Link to={`/avaliacao?company=${encodeURIComponent(company.name)}`}
              className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-xl font-semibold hover:opacity-90">
              <Star className="w-5 h-5" /> Avaliar esta empresa
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EmpresaDetailPage;
