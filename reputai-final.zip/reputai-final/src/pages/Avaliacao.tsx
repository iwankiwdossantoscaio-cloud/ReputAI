import React, { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Star, Send, ArrowLeft, Users, Gift, DollarSign, Plus, X, AlertTriangle, CheckCircle, Shield, Clock, Ban, Building2, MapPin } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useCompanies } from '@/hooks/useCompanies';
import { useToastContext } from '@/contexts/ToastContext';
import { checkProfanity, getSuggestion } from '@/utils/profanityFilter';

const AvaliacaoPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { companies, addEvaluation, addCompany } = useCompanies();
  const { showToast } = useToastContext();
  const [searchParams] = useSearchParams();

  const [companyName, setCompanyName] = useState(searchParams.get('company') || '');
  const [companySelected, setCompanySelected] = useState(false);
  const [sector, setSector] = useState('');
  const [location, setLocation] = useState('');
  const [address, setAddress] = useState('');
  const [rating, setRating] = useState(0);
  const [text, setText] = useState('');
  const [anonymous, setAnonymous] = useState(false);
  const [ambient, setAmbient] = useState('');
  const [selectedBenefits, setSelectedBenefits] = useState<string[]>([]);
  const [customBenefit, setCustomBenefit] = useState('');
  const [salaryAmount, setSalaryAmount] = useState('');
  const [salaryPeriod, setSalaryPeriod] = useState('mensal');
  const [showWarning, setShowWarning] = useState(false);
  const [warningAccepted, setWarningAccepted] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [profanityError, setProfanityError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const benefits = ['Plano de Saúde', 'Vale Alimentação', 'Vale Refeição', 'Vale Transporte', 'Seguro de Vida', 'Home Office', 'Flexibilidade de Horários', 'PLR/PPR', 'Gympass/Academia', 'Day Off Aniversário'];
  const ambients = [
    { value: 'ótimo', label: 'Ótimo', icon: '😄' },
    { value: 'bom', label: 'Bom', icon: '🙂' },
    { value: 'normal', label: 'Normal', icon: '😐' },
    { value: 'ruim', label: 'Ruim', icon: '😟' },
  ];

  const existingCompany = companyName ? companies.find(c => c.name.toLowerCase().trim() === companyName.toLowerCase().trim()) : null;
  const isNewCompany = companyName.trim().length >= 2 && !existingCompany;
  const showSuggestions = companyName.length >= 2 && !companySelected;
  const matchingSuggestions = showSuggestions
    ? companies.filter(c => c.name.toLowerCase().includes(companyName.toLowerCase())).slice(0, 5)
    : [];

  const toggleBenefit = (b: string) => setSelectedBenefits(prev => prev.includes(b) ? prev.filter(x => x !== b) : [...prev, b]);
  const addCustomBenefitFn = () => {
    if (customBenefit.trim() && !selectedBenefits.includes(customBenefit.trim())) {
      setSelectedBenefits(prev => [...prev, customBenefit.trim()]);
      setCustomBenefit('');
    }
  };

  const handleSubmit = () => {
    if (!currentUser) { showToast('Faça login para avaliar', 'info'); return; }
    if (!companyName || !rating || !text) { showToast('Preencha todos os campos obrigatórios', 'error'); return; }
    if (text.length < 50) { showToast('A avaliação deve ter pelo menos 50 caracteres', 'error'); return; }
    if (salaryAmount && (isNaN(Number(salaryAmount)) || Number(salaryAmount) <= 0 || Number(salaryAmount) > 1000000)) {
      showToast('Faixa salarial inválida', 'error'); return;
    }

    const result = checkProfanity(text);
    if (!result.isClean && !result.isSuspicious) {
      setProfanityError(getSuggestion(result.foundWords));
      showToast('Sua avaliação contém linguagem ofensiva. Por favor, reescreva.', 'error');
      return;
    }
    setProfanityError(null);
    setShowWarning(true);
  };

  const confirmSubmit = async () => {
    if (!warningAccepted) { showToast('Aceite os termos para continuar', 'error'); return; }
    if (!currentUser) return;
    setSubmitting(true);

    const profanityResult = checkProfanity(text);
    const isSuspicious = profanityResult.isSuspicious;

    let companyId: string;
    if (existingCompany) {
      companyId = existingCompany.id;
    } else {
      const newCompany = await addCompany({
        name: companyName,
        sector: sector || 'Outros',
        location: address || location || 'Não informado',
        lat: -15 + (Math.random() - 0.5) * 20,
        lng: -50 + (Math.random() - 0.5) * 20,
        description: `Empresa cadastrada via avaliação`,
        average_rating: 0,
        review_count: 0,
        phone: '',
        email: '',
        website: '',
        cnpj: '',
      });
      if (!newCompany) { showToast('Erro ao cadastrar empresa', 'error'); setSubmitting(false); return; }
      companyId = newCompany.id;
      showToast(`Empresa "${companyName}" cadastrada e adicionada ao mapa!`, 'success');
    }

    const ok = await addEvaluation({
      company_id: companyId,
      user_id: currentUser.id,
      user_name: currentUser.name,
      rating,
      text,
      date: new Date().toISOString(),
      aviso_aceito: true,
      termos_aceitos_em: new Date().toISOString(),
      ambient: ambient || undefined,
      benefits: selectedBenefits.length > 0 ? selectedBenefits : undefined,
      salary_amount: salaryAmount || undefined,
      salary_period: salaryAmount ? salaryPeriod : undefined,
      anonymous,
      flagged_profanity: isSuspicious || undefined,
    });

    setSubmitting(false);
    if (ok) {
      setShowWarning(false);
      setSubmitted(true);
      showToast('Avaliação enviada! Será revisada antes de aparecer publicamente.', 'success');
    } else {
      showToast('Erro ao enviar avaliação', 'error');
    }
  };

  if (submitted) {
    return (
      <div className="pt-20">
        <section className="py-8 text-center" style={{ background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)' }}>
          <div className="container mx-auto px-5">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Avaliação Enviada!</h1>
          </div>
        </section>
        <section className="py-20">
          <div className="container mx-auto px-5 max-w-lg text-center">
            <div className="bg-card p-8 rounded-xl shadow-md">
              <Clock className="w-16 h-16 mx-auto text-warning mb-4" />
              <h2 className="text-2xl font-bold text-foreground mb-3">Em Análise</h2>
              <p className="text-muted-foreground mb-2">Sua avaliação está aguardando aprovação da moderação.</p>
              <p className="text-sm text-muted-foreground mb-6">Enquanto isso, ela ficará visível apenas para você no seu perfil.</p>
              <div className="flex flex-col gap-3">
                <Link to="/perfil" className="inline-flex items-center justify-center gap-2 px-4 py-3 bg-primary text-primary-foreground rounded-lg font-medium">Ver meu perfil</Link>
                <button onClick={() => { setSubmitted(false); setCompanyName(''); setSector(''); setLocation(''); setAddress(''); setRating(0); setText(''); setAnonymous(false); setAmbient(''); setSelectedBenefits([]); setSalaryAmount(''); setWarningAccepted(false); }}
                  className="inline-flex items-center justify-center gap-2 px-4 py-3 border border-input rounded-lg font-medium text-foreground hover:bg-secondary">
                  Avaliar outra empresa
                </button>
                <Link to="/" className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm text-muted-foreground hover:text-foreground">
                  <ArrowLeft className="w-4 h-4" /> Voltar para Home
                </Link>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="pt-20">
      <section className="py-8 text-center" style={{ background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)' }}>
        <div className="container mx-auto px-5">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Avaliar uma Empresa</h1>
          <p className="text-white/80">Compartilhe sua experiência para ajudar outros profissionais</p>
        </div>
      </section>

      <section className="py-10">
        <div className="container mx-auto px-5 max-w-2xl">
          <div className="flex items-start gap-3 p-4 bg-warning/10 border border-warning/30 rounded-xl mb-6">
            <Shield className="w-5 h-5 text-warning shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-foreground">Moderação ativa</p>
              <p className="text-xs text-muted-foreground">Todas as avaliações passam por análise antes de serem publicadas.</p>
            </div>
          </div>

          <div className="bg-card p-8 rounded-xl shadow-md">
            <h3 className="text-xl font-bold text-foreground mb-6">Conte sua experiência de trabalho</h3>

            <div className="mb-5 relative">
              <label className="block text-sm font-medium mb-1 text-foreground">Nome da Empresa *</label>
              <input value={companyName} onChange={e => { setCompanyName(e.target.value); setCompanySelected(false); }} placeholder="Digite o nome da empresa"
                className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
              
              {matchingSuggestions.length > 0 && (
                <div className="absolute z-10 w-full mt-1 bg-card border border-border rounded-lg shadow-lg max-h-40 overflow-y-auto">
                  {matchingSuggestions.map(c => (
                    <button key={c.id} type="button" onClick={() => { setCompanyName(c.name); setCompanySelected(true); }}
                      className="w-full text-left px-3 py-2 text-sm text-foreground hover:bg-secondary flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-primary shrink-0" />
                      <span>{c.name}</span>
                      <span className="text-xs text-muted-foreground ml-auto">{c.sector}</span>
                    </button>
                  ))}
                </div>
              )}

              {isNewCompany && (
                <div className="mt-2 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                  <p className="text-sm font-medium text-primary flex items-center gap-2">
                    <Building2 className="w-4 h-4" /> Empresa não encontrada — será cadastrada automaticamente!
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">O administrador poderá completar as informações e localização depois.</p>
                </div>
              )}
            </div>

            {isNewCompany && (
              <div className="mb-5 p-4 bg-secondary rounded-lg border-l-4 border-primary">
                <label className="block text-sm font-medium mb-1 text-foreground flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-primary" /> Endereço da Empresa (opcional)
                </label>
                <input value={address} onChange={e => setAddress(e.target.value)} placeholder="Cole o endereço completo (Ex: Av. Paulista, 1000 - São Paulo, SP)"
                  className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
                <small className="text-xs text-muted-foreground mt-1 block">💡 Opcional: O endereço ajuda a localizar no mapa, mas o administrador pode adicionar depois.</small>
              </div>
            )}

            {/* ... rest of form fields ... */}
            <div className="mb-5">
              <label className="block text-sm font-medium mb-1 text-foreground">Setor</label>
              <select value={sector} onChange={e => setSector(e.target.value)}
                className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none">
                <option value="">Selecione (opcional)</option>
                {['Tecnologia','Finanças','Saúde','Varejo','Serviços','Energia','Educação','Indústria','Construção Civil','Agronegócio','Outros'].map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div className="mb-5">
              <label className="block text-sm font-medium mb-1 text-foreground">Localização</label>
              <input value={location} onChange={e => setLocation(e.target.value)} placeholder="Cidade, Estado (opcional)"
                className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
            </div>

            <div className="flex items-start gap-3 p-4 bg-primary/5 rounded-lg border border-primary/20 mb-5">
              <input type="checkbox" checked={anonymous} onChange={e => setAnonymous(e.target.checked)} className="mt-1 w-4 h-4" />
              <div>
                <label className="font-medium text-foreground text-sm cursor-pointer">Tornar anônima</label>
                <small className="block text-muted-foreground text-xs mt-1">Sua identidade será mantida em sigilo para outros usuários</small>
              </div>
            </div>

            <div className="mb-5">
              <label className="block text-sm font-medium mb-2 text-foreground">Avaliação Geral *</label>
              <div className="flex gap-1">
                {[1,2,3,4,5].map(i => (
                  <button key={i} type="button" onClick={() => setRating(i)} className="text-3xl transition-colors">
                    <Star className={`w-8 h-8 ${i <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-border'}`} />
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-secondary p-5 rounded-lg border-l-4 border-primary mb-5">
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2"><Users className="w-4 h-4" /> Ambiente (Opcional)</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {ambients.map(a => (
                  <button key={a.value} type="button" onClick={() => setAmbient(a.value)}
                    className={`p-3 rounded-lg border-2 text-center text-sm font-medium transition-all ${ambient === a.value ? 'border-primary bg-primary text-primary-foreground' : 'border-input bg-background text-foreground hover:border-primary'}`}>
                    {a.icon} {a.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-secondary p-5 rounded-lg border-l-4 border-primary mb-5">
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2"><Gift className="w-4 h-4" /> Benefícios (Opcional)</h4>
              <div className="grid grid-cols-2 gap-2 mb-3">
                {benefits.map(b => (
                  <button key={b} type="button" onClick={() => toggleBenefit(b)}
                    className={`p-2 rounded-lg border-2 text-left text-xs font-medium transition-all ${selectedBenefits.includes(b) ? 'border-success bg-success/10 text-foreground' : 'border-input bg-background text-foreground hover:border-primary'}`}>
                    {selectedBenefits.includes(b) ? '✅' : '⬜'} {b}
                  </button>
                ))}
              </div>
              <div className="flex gap-2">
                <input value={customBenefit} onChange={e => setCustomBenefit(e.target.value)} placeholder="Benefício personalizado"
                  className="flex-1 px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                <button type="button" onClick={addCustomBenefitFn} className="px-3 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="bg-secondary p-5 rounded-lg border-l-4 border-primary mb-5">
              <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2"><DollarSign className="w-4 h-4" /> Faixa Salarial (Opcional)</h4>
              <div className="flex gap-2">
                <input value={salaryAmount} onChange={e => setSalaryAmount(e.target.value)} placeholder="Ex: 5000"
                  className="flex-1 px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground text-sm focus:border-primary focus:outline-none" />
                <select value={salaryPeriod} onChange={e => setSalaryPeriod(e.target.value)}
                  className="px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground text-sm">
                  <option value="mensal">Mensal</option>
                  <option value="anual">Anual</option>
                </select>
              </div>
            </div>

            <div className="mb-5">
              <label className="block text-sm font-medium mb-1 text-foreground">Sua Avaliação * (mín. 50 caracteres)</label>
              <textarea value={text} onChange={e => setText(e.target.value)} rows={5} placeholder="Conte sua experiência..."
                className="w-full px-3 py-3 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none resize-y" />
              <small className={`text-xs ${text.length >= 50 ? 'text-success' : 'text-muted-foreground'}`}>{text.length}/50</small>
              {profanityError && (
                <div className="mt-2 p-3 bg-destructive/10 border border-destructive/30 rounded-lg flex items-start gap-2">
                  <Ban className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-destructive">Conteúdo ofensivo detectado</p>
                    <p className="text-xs text-muted-foreground mt-1">{profanityError}</p>
                  </div>
                </div>
              )}
            </div>

            <button onClick={handleSubmit}
              className="w-full py-4 bg-primary text-primary-foreground rounded-lg font-semibold flex items-center justify-center gap-2 hover:opacity-90 transition-opacity text-lg">
              <Send className="w-5 h-5" /> Enviar Avaliação
            </button>
          </div>

          <div className="text-center mt-8">
            <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium">
              <ArrowLeft className="w-4 h-4" /> Voltar para Home
            </Link>
          </div>
        </div>
      </section>

      {showWarning && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[2000] p-5 animate-fade-in" onClick={() => setShowWarning(false)}>
          <div className="bg-card rounded-xl w-full max-w-lg overflow-hidden animate-scale-in shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="p-6 text-center text-white" style={{ background: 'linear-gradient(135deg, #f59e0b, #d97706)' }}>
              <AlertTriangle className="w-10 h-10 mx-auto mb-2" />
              <h2 className="text-xl font-bold">Política de Avaliações</h2>
            </div>
            <div className="p-6 space-y-3 max-h-[60vh] overflow-y-auto">
              {[
                { icon: CheckCircle, color: 'text-primary', text: 'Sua avaliação deve ser baseada em experiência real.' },
                { icon: Shield, color: 'text-success', text: 'Não inclua calúnia, difamação ou informações falsas.' },
                { icon: Ban, color: 'text-destructive', text: 'Avaliações com linguagem ofensiva serão rejeitadas.' },
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-3 p-3 bg-secondary rounded-lg">
                  <item.icon className={`w-5 h-5 ${item.color} shrink-0 mt-0.5`} />
                  <p className="text-sm text-foreground">{item.text}</p>
                </div>
              ))}
              <div className="flex items-start gap-3 p-4 bg-warning/10 rounded-lg border border-warning/30 mt-4">
                <input type="checkbox" checked={warningAccepted} onChange={e => setWarningAccepted(e.target.checked)} className="mt-1 w-4 h-4" />
                <label className="text-sm text-foreground font-medium cursor-pointer">
                  Li e aceito os termos. Confirmo que minha avaliação é baseada em experiência real.
                </label>
              </div>
            </div>
            <div className="p-4 border-t border-border flex gap-3">
              <button onClick={() => setShowWarning(false)} className="flex-1 py-3 border border-input rounded-lg font-medium text-foreground hover:bg-secondary">Cancelar</button>
              <button onClick={confirmSubmit} disabled={!warningAccepted || submitting}
                className="flex-1 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 disabled:opacity-50">
                {submitting ? 'Enviando...' : 'Confirmar Envio'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AvaliacaoPage;
