import React, { useState, useMemo, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Building2, Filter, ArrowLeft, Star, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { useCompanies } from '@/hooks/useCompanies';
import CompanyCard from '@/components/CompanyCard';

const PAGE_SIZE = 15;

const EmpresasPage: React.FC = () => {
  const { companies, evaluations } = useCompanies();
  const navigate = useNavigate();
  const [nameFilter, setNameFilter] = useState('');
  const [sectorFilter, setSectorFilter] = useState('');
  const [locationFilter, setLocationFilter] = useState('');
  const [minRating, setMinRating] = useState(0);
  const [onlyReviewed, setOnlyReviewed] = useState(false);
  const [sortBy, setSortBy] = useState('nome');
  const [page, setPage] = useState(1);

  const sectors = useMemo(() => [...new Set(companies.map(c => c.sector))], [companies]);
  const locations = useMemo(() => [...new Set(companies.map(c => c.location))].sort(), [companies]);
  const totalReviews = evaluations.length;
  const avgRating = companies.length > 0
    ? (companies.reduce((sum, c) => sum + c.average_rating, 0) / companies.length).toFixed(1)
    : '0.0';

  const filtered = useMemo(() => {
    let result = [...companies];
    if (nameFilter) {
      const q = nameFilter.toLowerCase();
      result = result.filter(c =>
        c.name.toLowerCase().includes(q) ||
        (c.description || '').toLowerCase().includes(q) ||
        c.sector.toLowerCase().includes(q) ||
        c.location.toLowerCase().includes(q)
      );
    }
    if (sectorFilter) result = result.filter(c => c.sector === sectorFilter);
    if (locationFilter) result = result.filter(c => c.location.toLowerCase().includes(locationFilter.toLowerCase()));
    if (minRating > 0) result = result.filter(c => c.average_rating >= minRating);
    if (onlyReviewed) result = result.filter(c => c.review_count > 0);
    switch (sortBy) {
      case 'rating-desc': result.sort((a, b) => b.average_rating - a.average_rating); break;
      case 'rating-asc': result.sort((a, b) => a.average_rating - b.average_rating); break;
      case 'avaliacoes-desc': result.sort((a, b) => b.review_count - a.review_count); break;
      case 'avaliacoes-asc': result.sort((a, b) => a.review_count - b.review_count); break;
      case 'nome-desc': result.sort((a, b) => b.name.localeCompare(a.name)); break;
      default: result.sort((a, b) => a.name.localeCompare(b.name));
    }
    return result;
  }, [companies, nameFilter, sectorFilter, locationFilter, minRating, onlyReviewed, sortBy]);

  // Reset to page 1 whenever filters change
  useEffect(() => { setPage(1); }, [nameFilter, sectorFilter, locationFilter, minRating, onlyReviewed, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const clearFilters = () => {
    setNameFilter(''); setSectorFilter(''); setLocationFilter('');
    setMinRating(0); setOnlyReviewed(false); setSortBy('nome');
  };

  const hasActiveFilters = nameFilter || sectorFilter || locationFilter || minRating > 0 || onlyReviewed || sortBy !== 'nome';

  const pageNumbers = useMemo(() => {
    const pages: (number | 'ellipsis')[] = [];
    const maxVisible = 5;
    if (totalPages <= maxVisible + 2) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      const start = Math.max(2, currentPage - 1);
      const end = Math.min(totalPages - 1, currentPage + 1);
      if (start > 2) pages.push('ellipsis');
      for (let i = start; i <= end; i++) pages.push(i);
      if (end < totalPages - 1) pages.push('ellipsis');
      pages.push(totalPages);
    }
    return pages;
  }, [currentPage, totalPages]);

  return (
    <div className="pt-20">
      <section className="py-8 text-center" style={{ background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)' }}>
        <div className="container mx-auto px-5">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Banco de Dados de Empresas</h1>
          <p className="text-white/80">Todas as empresas avaliadas na plataforma ReputAí</p>
        </div>
      </section>

      <section className="py-8">
        <div className="container mx-auto px-5">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { value: companies.length, label: 'Empresas' },
              { value: totalReviews, label: 'Avaliações' },
              { value: avgRating, label: 'Média Geral' },
              { value: sectors.length, label: 'Setores' },
            ].map((s, i) => (
              <div key={i} className="text-center p-4 bg-card rounded-xl shadow-sm">
                <div className="text-3xl font-bold text-primary mb-1">{s.value}</div>
                <div className="text-sm text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-4">
        <div className="container mx-auto px-5">
          <div className="bg-card p-6 rounded-xl shadow-md">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <h3 className="font-bold text-foreground flex items-center gap-2"><Filter className="w-5 h-5" /> Filtrar e buscar</h3>
              {hasActiveFilters && (
                <button onClick={clearFilters} className="text-sm text-primary hover:underline flex items-center gap-1">
                  <X className="w-4 h-4" /> Limpar filtros
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">Busca</label>
                <input value={nameFilter} onChange={e => setNameFilter(e.target.value)} placeholder="Nome, setor, local..."
                  className="w-full px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">Setor</label>
                <select value={sectorFilter} onChange={e => setSectorFilter(e.target.value)}
                  className="w-full px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none">
                  <option value="">Todos os setores</option>
                  {sectors.sort().map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">Localização</label>
                <select value={locationFilter} onChange={e => setLocationFilter(e.target.value)}
                  className="w-full px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none">
                  <option value="">Todas as localizações</option>
                  {locations.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">Ordenar</label>
                <select value={sortBy} onChange={e => setSortBy(e.target.value)}
                  className="w-full px-3 py-2 border-2 border-input rounded-lg bg-background text-foreground focus:border-primary focus:outline-none">
                  <option value="nome">Nome (A-Z)</option>
                  <option value="nome-desc">Nome (Z-A)</option>
                  <option value="rating-desc">Avaliação ↓</option>
                  <option value="rating-asc">Avaliação ↑</option>
                  <option value="avaliacoes-desc">Mais avaliações</option>
                  <option value="avaliacoes-asc">Menos avaliações</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div>
                <label className="block text-sm font-medium mb-1 text-foreground">
                  Avaliação mínima: <span className="text-primary font-bold">{minRating > 0 ? `${minRating}★` : 'Qualquer'}</span>
                </label>
                <input type="range" min={0} max={5} step={1} value={minRating}
                  onChange={e => setMinRating(Number(e.target.value))}
                  className="w-full accent-primary" />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-2 cursor-pointer text-sm text-foreground">
                  <input type="checkbox" checked={onlyReviewed} onChange={e => setOnlyReviewed(e.target.checked)}
                    className="w-4 h-4 accent-primary" />
                  Apenas empresas já avaliadas
                </label>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-10">
        <div className="container mx-auto px-5">
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
            <p className="text-sm text-muted-foreground">
              {filtered.length === 0 ? 'Nenhum resultado' :
                `Mostrando ${(currentPage - 1) * PAGE_SIZE + 1}–${Math.min(currentPage * PAGE_SIZE, filtered.length)} de ${filtered.length} empresas`}
            </p>
            {totalPages > 1 && (
              <p className="text-sm text-muted-foreground">Página {currentPage} de {totalPages}</p>
            )}
          </div>
          {filtered.length === 0 ? (
            <div className="text-center py-12">
              <Building2 className="w-16 h-16 mx-auto text-border mb-4" />
              <h3 className="text-xl font-bold text-foreground mb-2">Nenhuma empresa encontrada</h3>
              <p className="text-muted-foreground mb-4">Tente ajustar os filtros de busca</p>
              <Link to="/avaliacao" className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium">
                <Star className="w-4 h-4" /> Avaliar
              </Link>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {pageItems.map(c => <CompanyCard key={c.id} company={c} onClick={() => navigate(`/empresa/${c.id}`)} />)}
              </div>
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-10 flex-wrap">
                  <button
                    onClick={() => { setPage(p => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                    disabled={currentPage === 1}
                    className="px-3 py-2 rounded-lg border-2 border-input bg-background text-foreground disabled:opacity-40 disabled:cursor-not-allowed hover:border-primary transition-colors flex items-center gap-1">
                    <ChevronLeft className="w-4 h-4" /> Anterior
                  </button>
                  {pageNumbers.map((p, i) =>
                    p === 'ellipsis' ? (
                      <span key={`e-${i}`} className="px-2 text-muted-foreground">…</span>
                    ) : (
                      <button key={p} onClick={() => { setPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                        className={`w-10 h-10 rounded-lg border-2 font-semibold transition-colors ${
                          p === currentPage
                            ? 'bg-primary text-primary-foreground border-primary'
                            : 'border-input bg-background text-foreground hover:border-primary'
                        }`}>
                        {p}
                      </button>
                    )
                  )}
                  <button
                    onClick={() => { setPage(p => Math.min(totalPages, p + 1)); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                    disabled={currentPage === totalPages}
                    className="px-3 py-2 rounded-lg border-2 border-input bg-background text-foreground disabled:opacity-40 disabled:cursor-not-allowed hover:border-primary transition-colors flex items-center gap-1">
                    Próxima <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </>
          )}
          <div className="text-center mt-12">
            <Link to="/" className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium hover:opacity-90">
              <ArrowLeft className="w-4 h-4" /> Voltar
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EmpresasPage;
