
ALTER PUBLICATION supabase_realtime DROP TABLE public.admin_notifications;
